create table Emp_sara 
(empID 		varchar(20),
empName 	varchar(20),
primary key (empID)
);
create table Customer_sara 
(customerNo 	varchar(20) ,
cName 		varchar(20),
primary key (customerNo)
);
create table SaleOrder_sara 
(saleNo 		varchar(20),
date 		date,
customerNo 	varchar(20),
empID 		varchar(20),
primary key (saleNo),
foreign key (empID) references Emp_sara (empID),
foreign key (customerNo) references Customer_sara (customerNo)
);
create table SO_details_sara 
(saleNo		varchar(20),
itemNo 		varchar(20),
quantity 		varchar(5),
primary key (saleNo, itemNo), 
foreign key (saleNo) references SaleOrder_sara (saleNo),
foreign key (itemNo) references Item_sara (itemNo)
);
create table Item_sara
(itemNo		 varchar(20),
description 	varchar(20) not null,
unitPrice 		varchar(20),
primary key (itemNo)
);

insert into Item_sara values (1,'coffee' , 0.60);
insert into Item_sara values (2,'tissues' , 0.20);
insert into Item_sara values (3,'juice' , 0.45);
insert into Item_sara values (4,'soda' , 0.50);
insert into Item_sara values (5,'tea' , 0.30);
insert into Item_sara values (6,'soap' , 0.15);
insert into Item_sara values (7,'chips' , 0.35);
insert into Item_sara values (8,'biscuits' , 0.80);
insert into Item_sara values (9,'chocolate' , 0.30);
insert into Item_sara values (10,'cornflakes' , 0.80);
insert into Item_sara values (11,'shampoo' , 0.50);
insert into Item_sara values (12,'gum' , 0.30);
insert into Item_sara values (13,'ice cream' , 1.0);
insert into Item_sara values (14,'water bottle' , 0.25);
insert into Item_sara values (15,'eggs' , 0.80);
insert into Item_sara values (16,'vinegar' , 0.35);
insert into Item_sara values (17,'nutella' , 0.75);
insert into Item_sara values (18,'butter' , 0.20);
insert into Item_sara values (19,'milk' , 0.55);
insert into Item_sara values (20,'sugar' , 0.90);
insert into Item_sara values (21,'salt' , 0.60);
insert into Item_sara values (22,'flour' , 1.20);
insert into Item_sara values (23,'pasta' , 0.70);

insert into Customer_sara values (1,'Martha');
insert into Customer_sara values (2,'Lily');
insert into Customer_sara values (3,'John');
insert into Customer_sara values (4,'William');
insert into Customer_sara values (5,'Sheryl');
insert into Customer_sara values (6,'Abby');
insert into Customer_sara values (7,'Charlie');
insert into Customer_sara values (8,'Nate');
insert into Customer_sara values (9,'Rose');
insert into Customer_sara values (10,'Scott');
insert into Customer_sara values (11,'Louis');
insert into Customer_sara values (12,'George');
insert into Customer_sara values (13,'Yasmine');

insert into Emp_sara values (1,'Grace');
insert into Emp_sara values (2,'Danny');
insert into Emp_sara values (3,'Martin');
insert into Emp_sara values (4,'Blake');
insert into Emp_sara values (5,'Sasha');

insert into SaleOrder_sara values (1,'14/3/2019' ,1, 5);
insert into SaleOrder_sara values (2,'2/4/2019' ,2, 2);
insert into SaleOrder_sara values (8,'23/5/2019' ,3, 2);
insert into SaleOrder_sara values (16,'14/3/2019' ,5, 4);
insert into SaleOrder_sara values (133,'8/1/2020' ,13, 1);
insert into SaleOrder_sara values (20,'27/6/2019' ,7, 3);
insert into SaleOrder_sara values (49,'31/7/2019' ,8, 5);
insert into SaleOrder_sara values (18,'18/6/2019' ,6, 1);
insert into SaleOrder_sara values (50,'2/8/2019' ,9, 3);
insert into SaleOrder_sara values (10,'1/6/2019' ,4, 5);

insert into SO_details_sara values (1,12, 2);
insert into SO_details_sara values (1,4, 6);
insert into SO_details_sara values (2,20, 1);
insert into SO_details_sara values (2,21, 1);
insert into SO_details_sara values (2,19, 3);
insert into SO_details_sara values (8,1, 1);
insert into SO_details_sara values (18,5, 7);
insert into SO_details_sara values (18,12, 2);
insert into SO_details_sara values (50,7, 8);
insert into SO_details_sara values (8,23, 3);
insert into SO_details_sara values (20,8, 1);
insert into SO_details_sara values (49,4, 10);
insert into SO_details_sara values (20,20, 4);
insert into SO_details_sara values (16,3, 1);
insert into SO_details_sara values (50,6, 1);
insert into SO_details_sara values (49,2, 1);
insert into SO_details_sara values (10,15, 5);
insert into SO_details_sara values (133,22, 3);

