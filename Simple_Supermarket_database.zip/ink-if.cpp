#include <iostream>
#include <mysql.h>
#include <stdio.h>
#include <stdlib.h>



using namespace std;

int main()
{

	MYSQL *conn;
	MYSQL_RES *res;
	MYSQL_ROW row;

	char *server="127.0.0.1";
	char *user="root";
	char *password="kitoo";
	char *database="myst";

	conn=mysql_init(NULL);
	if(!mysql_real_connect(conn,server,user,password,database,0,NULL,0))
	{
	cout<<stderr<<"\n"<<mysql_errno(conn);
	return -1;
	}

	
	mysql_query(conn,"insert into SaleOrder_sara values (10,'1/6/2019' ,4, 5)");

	mysql_query(conn,"insert into SO_details_sara values (1,12, 2)");
	mysql_query(conn,"insert into Customer_sara values (13,'Yasmine')");

	mysql_query(conn,"insert into Emp_sara values (1,'Grace')");
	mysql_query(conn,"insert into Item_sara values (1,'coffee' , 0.60)");
	if(mysql_query(conn,"select * from tab"))
	{
		cout<<stderr<<"\n"<<mysql_errno(conn);
		return -1;
	}
	res=mysql_use_result(conn);
	cout<<"\sale order nom:"<<"\cos nom:"<<"\emp ID :"<<endl;
	while ((row=mysql_fetch_row(res))!=NULL)
	{
	cout<<"\t"<<row[0]<<"\t"<<row[1]<<"\t"<<row[2]<<endl;
	}



	mysql_free_result(res);
	mysql_close(conn);

return 0;
}